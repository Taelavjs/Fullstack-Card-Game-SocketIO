
--- THANK U -----------------

Thank you for downloading this Cute Card Set :) hope you like it and find it usefull
This project it's idependent. But was originaly made as part of a Super Pixel Card Set, comming in the future,
follow me on itch.io to see the updates. @danimaccari -> https://dani-maccari.itch.io/


--- HOW TO USE --------------

The pack contains 60 diferent cards 15 in each row

Each Card is 100x144 pixels

Each row contains one color
	Clubs
	Diamonds
	Spades
	Hearts

Contains two joker designs, two fade down cards and two blank cards

There are 15 POKER CHIPS each one 76x76 pixels

--- PIXEL ASSETS -----------

Each Card is 25x36 pixels
Each Chip is 19x19 pixels

--- LICENSE ----------------

This pack is free for personal or comercial use as long as it's atributed to DANI MACCARI.
You are free to edit the sprites as much as you want.
You may not repackage, redistribute or resell the assets, no matter how much they are modified. - This includes NFTs.